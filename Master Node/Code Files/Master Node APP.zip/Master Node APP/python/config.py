"""Firebase configuration for Jal Rakshak Master Node.

Store your Firebase credentials here. This file should NOT be committed
to version control — add it to .gitignore.

To obtain these values:
1. Open https://console.firebase.google.com
2. Select your Jal-Rakshak project
3. FIREBASE_URL: Realtime Database > Data tab > copy the URL at the top
4. FIREBASE_AUTH: Project Settings > Service Accounts > Database secrets > Show
"""

import os

# Firebase Realtime Database URL
FIREBASE_URL = os.environ.get(
    "JR_FIREBASE_URL",
    os.environ.get("SWG_FIREBASE_URL", "https://your-project-id-default-rtdb.firebaseio.com")
)

# Firebase legacy database secret (alphanumeric string)
FIREBASE_AUTH = os.environ.get(
    "JR_FIREBASE_AUTH",
    os.environ.get("SWG_FIREBASE_AUTH", "PASTE_YOUR_DATABASE_SECRET_HERE")
)

# WiFi is managed by the Dragonwing Linux OS (nmcli) — no WiFi credentials needed here.
